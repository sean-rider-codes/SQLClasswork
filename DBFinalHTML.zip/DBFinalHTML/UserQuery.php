<?php
$servername = "rei.cs.ndsu.nodak.edu";
$username = "acherli_366f16";
$password = "tlrhdo4amu";
$dbname = "ascherli_366f16";

echo "Attempting to connect";
$con = new mysqli($servername, $username, $password, $dbname);
if($con->connect_error)
	{
		die("Connection Failed: " . $con->connect_error);
	}
echo "Connection Established. <br>";

$sqlSelect = "SELECT * FROM UserTable";
$result = $con->query($sqlSelect);

echo "<table>";
echo "This should work";

while($row = mysql_fetch_array($result))
	{
		echo "<tr><td>" . $row['userID'] . "</td><td>" . $row['userName'] . "</td></tr>";
	}
echo "</table>";

mysql_close();
?> 
