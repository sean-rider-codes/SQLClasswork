Code for joining point and program tables here
