Code for calculating AVG() of X clicks here
