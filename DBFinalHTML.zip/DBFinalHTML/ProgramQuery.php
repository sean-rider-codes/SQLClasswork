<?php
$host = 'rei.cs.ndsu.nodak.edu';
$username = 'srider_366f16';
$dbname = 'srider_366f16';
$password = 'kH6PNxhn7d';

//Create Connection
$con = new mysqli($host, $username, $password, $dbname);
//create connection and check
if($con->connect_error)
	{
		die("Connection failed: " . $con->connect_error);
	}
if(isset($_GET['sort_button']))
	{
	
	}
else if (isset($_GET['next_button']))
	{
		header('location : http://students.cs.ndsu.nodak.edu/~srider/FinalProjectHTML/DBFinalHTML/CoordinateForm.html')
	}
?>
