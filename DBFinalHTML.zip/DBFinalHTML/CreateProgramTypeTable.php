Code for Creating Program Type Table
