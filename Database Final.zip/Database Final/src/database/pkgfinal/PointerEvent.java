package database.pkgfinal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Sean Rider
 */
public class PointerEvent extends JFrame {
    
    //private JFrame mousePanel;
    private JLabel statusBar;
    private JPanel jp;
    
    public PointerEvent()
    {
        super("title");
        
        jp = new JPanel();
        jp.setSize(MAXIMIZED_HORIZ, MAXIMIZED_VERT);
        //jp.setBackground(new Color(0,0,0,0));
        //jp.setOpaque(true);
        add(jp, BorderLayout.CENTER);
        
       /* mousePanel = new JFrame();
        mousePanel.setExtendedState(JFrame.MAXIMIZED_BOTH);
        mousePanel.setVisible(true);
        */
        
        statusBar = new JLabel("default");
        add(statusBar, BorderLayout.SOUTH);
        
       /* HandlerClass handler = new HandlerClass();
        mousePanel.addMouseListener(handler);
        mousePanel.addMouseMotionListener(handler);
        */
        HandlerClass handler = new HandlerClass();
        jp.addMouseListener(handler);
        jp.addMouseMotionListener(handler);
        
    }
    
    private class HandlerClass implements MouseListener, MouseMotionListener
    {
        @Override
        public void mouseClicked(MouseEvent e)
        {
            statusBar.setText(e.getX() + "," + e.getY());
            System.out.println(e.getX() + " " + e.getY());
        }

        @Override
        public void mousePressed(MouseEvent e) {
            statusBar.setText("Mouse Press: " + e.getX() + "," + e.getY());
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            statusBar.setText("Mouse Release: " + e.getX() + "," + e.getY());
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            statusBar.setText("Entered new area");
        }

        @Override
        public void mouseExited(MouseEvent e) {
            statusBar.setText("exited area");
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            statusBar.setText("Mouse Dragged: " + e.getX() + "," + e.getY());
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            statusBar.setText("Mouse Moved: " + e.getX() + "," + e.getY());
        }
    }

    public void mouseClick(MouseEvent e)
    {
        int x = e.getX();
        int y = e.getY();
        System.out.println(x + "," + y);
    }

}
