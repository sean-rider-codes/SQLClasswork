Code for calculating AVG() Y click here
