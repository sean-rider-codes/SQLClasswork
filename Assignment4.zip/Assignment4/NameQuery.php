<?php
$servername = "rei.cs.ndsu.nodak.edu";
$username = "srider_366f16";
$password = "kH6PNxhn7d";
$dbname = "srider_366f16";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connection established <br> ";
$name = $_GET["name"];
$sql = "SELECT * FROM Customer WHERE lname = '$name'";
$result = $conn->query($sql);
echo "Search for: " . $name . "<br>";

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["cid"]. " Name: " . $row["fname"]. " " . $row["lname"]. " " . "Address: " . $row["street"]. " " . $row["city"]. " " . $row["zip"]. "<br>";
    }
} else {
    echo "Name was not found.";
}
$conn->close();
?>

<html>
<body>
<h5>Change Zip Code?</h5> 
<form action="ZipRefresh.php" method"get">
New Zip(not functional): <input type="text" zip="zip" pattern" [0-9]+">
<input type="Submit">
</form>
</body>
</html>


