Code for creating Settings table here
