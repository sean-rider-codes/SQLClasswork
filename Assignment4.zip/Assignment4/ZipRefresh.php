<?php
$servername = "rei.cs.ndsu.nodak.edu";
$username = "srider_366f16";
$password = "kH6PNxhn7d";
$dbname = "srider_366f16";

$conn = new msqli($servername, $username, $password, $dbname);

if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$zip = $_GET["zip"];
$name = $_SESSION['name'];
$sqlSelect = "SELECT * FROM Customer WHERE lname = '$name'";
$sqlZip = "UPDATE Customer SET zip='$zip' WHERE lname = '$name'";

$conn->query($sqlZip);
$result = $conn->query($sqlSelect);
echo "New zip: " . $zip . "<br>";

if($result->num_rows > 0) {
	//output rows
	while($row = $result->fetch_assoc()) {
		echo "id: " . $row["cid"]. " Name: " . $row["fname"]. " " . $row["lname"]. " " . "Address: " . $row["street"]. " " . $row["city"] . " " . $row["zip"]. "<br>";
	}
} else {
	echo"Could not update zip.";
}
$conn->close();
?>
