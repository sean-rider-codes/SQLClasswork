Code for deleting point here
