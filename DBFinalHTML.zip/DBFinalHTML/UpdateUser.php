Code for updating user here
