<html>
<body>
<title>Last Name Search</title>
<h3>Search by last name</h3>
<form action="NameQuery.php" method="get">
Last Name: <input type="text" name="name" required pattern="[a-zA-Z\s]+"> <br>
<input type="submit">
</form>

</body>
</html> 
