package database.pkgfinal;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author Sean Rider
 */
public class DatabaseFinal extends JFrame {

    public static void main(String[] args) {
        PointerEvent go = new PointerEvent();
        go.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        go.setExtendedState(go.getExtendedState() | JFrame.MAXIMIZED_BOTH);
        go.setVisible(true);
        //go.setUndecorated(true);
    }
}

